# wrangle-gtfs
Python script to wrangle GFTS. Tested with DK Rejseplanen GTFS data
